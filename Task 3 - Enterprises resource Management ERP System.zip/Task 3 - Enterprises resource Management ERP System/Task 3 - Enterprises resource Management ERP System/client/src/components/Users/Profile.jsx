import React, { useEffect, useRef } from "react";
import {
  GetProfileDetails,
  ProfileUpdateRequest,
} from "../../APIRequest/UsersAPIRequest";
import { useSelector } from "react-redux";
import {
  ErrorToast,
  ToBase64,
  IsEmail,
  IsEmpty,
  IsMobile,
} from "../../helper/FormHelper";
import { useNavigate } from "react-router-dom";

const Profile = () => {
  const emailRef = useRef();
  const firstNameRef = useRef();
  const lastNameRef = useRef();
  const mobileRef = useRef();
  const passwordRef = useRef();
  const userImgRef = useRef();
  const userImgView = useRef();

  useEffect(() => {
    (async () => {
      await GetProfileDetails();
    })();
  }, []);

  const ProfileData = useSelector((state) => state.profile.value);

  let navigate = useNavigate();

  const PreviewImage = () => {
    let ImgFile = userImgRef.files[0];
    ToBase64(ImgFile).then((base64Img) => {
      userImgView.src = base64Img;
    });
  };

  const UpdateMyProfile = async () => {
    let email = emailRef.current.value;
    let fastName = firstNameRef.current.value;
    let lastName = lastNameRef.current.value;
    let mobile = mobileRef.current.value;
    let password = passwordRef.current.value;
    let photo = userImgView.current.src;

    if (IsEmail(email)) {
      ErrorToast("Valid Email Address Required !");
    } else if (IsEmpty(fastName)) {
      ErrorToast("First Name Required !");
    } else if (IsEmpty(lastName)) {
      ErrorToast("Last Name Required !");
    } else if (!IsMobile(mobile)) {
      ErrorToast("Valid Mobile  Required !");
    } else if (IsEmpty(password)) {
      ErrorToast("Password Required !");
    } else {
      let result = await ProfileUpdateRequest(
        email,
        fastName,
        lastName,
        mobile,
        password,
        photo
      );
      if (result === true) {
        navigate("/");
      }
    }
  };

  return (
    <div className="container">
      <div className="row d-flex justify-content-center">
        <div className="col-md-12">
          <div className="card">
            <div className="card-body">
              <div className="container-fluid">
                <img
                  ref={userImgView}
                  className="icon-nav-img-lg"
                  src={ProfileData["photo"]}
                  alt=""
                />
                <hr />
                <div className="row">
                  <div className="col-4 p-2">
                    <label>Profile Picture</label>
                    <input
                      onChange={PreviewImage}
                      ref={userImgRef}
                      placeholder="User Email"
                      className="form-control animated fadeInUp"
                      type="file"
                    />
                  </div>
                  <div className="col-4 p-2">
                    <label>Email Address</label>
                    <input
                      defaultValue={ProfileData["email"]}
                      readOnly={true}
                      ref={emailRef}
                      placeholder="User Email"
                      className="form-control animated fadeInUp"
                      type="email"
                    />
                  </div>
                  <div className="col-4 p-2">
                    <label>First Name</label>
                    <input
                      defaultValue={ProfileData["firstName"]}
                      ref={firstNameRef}
                      placeholder="First Name"
                      className="form-control animated fadeInUp"
                      type="text"
                    />
                  </div>
                  <div className="col-4 p-2">
                    <label>Last Name</label>
                    <input
                      defaultValue={ProfileData["lastName"]}
                      ref={lastNameRef}
                      placeholder="Last Name"
                      className="form-control animated fadeInUp"
                      type="text"
                    />
                  </div>
                  <div className="col-4 p-2">
                    <label>Mobile</label>
                    <input
                      defaultValue={ProfileData["mobile"]}
                      ref={mobileRef}
                      placeholder="Mobile"
                      className="form-control animated fadeInUp"
                      type="mobile"
                    />
                  </div>
                  <div className="col-4 p-2">
                    <label>Password</label>
                    <input
                      defaultValue={ProfileData["password"]}
                      ref={passwordRef}
                      placeholder="User Password"
                      className="form-control animated fadeInUp"
                      type="password"
                    />
                  </div>
                  <div className="col-4 p-2">
                    <button
                      onClick={UpdateMyProfile}
                      className="w-100  btn btn-success">
                      Update
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
export default Profile;
